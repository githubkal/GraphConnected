package structures;

public class Pair<T> {
	public T left;
	public T right;

	public Pair(T left, T right) {
		this.left = left;
		this.right = right;
	}
}